package com.prachi.model;

public class Marks {
	private  String subjectid;
	private  String subjectname;
	private  String midterm1;
	private  String midterm2;
	private  String assignment1;
	private  String assignment2;
	private  String quiz1;
	private  String quiz2;
	private  String labquiz;
	private  String classattendance;
	private  String labattendance;
	private  String internalviva;
	private  String labperformance;
	private String total;
	private String enrollmentno;
	
/*	public String getTotal() {
		return total;
	}*/
	
	public void setTotal(String total) {
		this.total = total;
	}
	public String getEnrollmentno() {
		return enrollmentno;
	}
	public void setEnrollmentno(String enrollmentno) {
		this.enrollmentno = enrollmentno;
	}
	public String getSubjectid() {
		return subjectid;
	}
	public void setSubjectid(String subjectid) {
		this.subjectid = subjectid;
	}
	public String getSubjectname() {
		return subjectname;
	}
	public void setSubjectname(String subjectname) {
		this.subjectname = subjectname;
	}
	public String getMidterm1() {
		return midterm1;
	}
	public void setMidterm1(String midterm1) {
		this.midterm1 = midterm1;
	}
	public String getMidterm2() {
		return midterm2;
	}
	public void setMidterm2(String midterm2) {
		this.midterm2 = midterm2;
	}
	public String getAssignment1() {
		return assignment1;
	}
	public void setAssignment1(String assignment1) {
		this.assignment1 = assignment1;
	}
	public String getAssignment2() {
		return assignment2;
	}
	public void setAssignment2(String assignment2) {
		this.assignment2 = assignment2;
	}
	public String getQuiz1() {
		return quiz1;
	}
	public void setQuiz1(String quiz1) {
		this.quiz1 = quiz1;
	}
	public String getQuiz2() {
		return quiz2;
	}
	public void setQuiz2(String quiz2) {
		this.quiz2 = quiz2;
	}
	public String getLabquiz() {
		return labquiz;
	}
	public void setLabquiz(String labquiz) {
		this.labquiz = labquiz;
	}
	public String getClassattendance() {
		return classattendance;
	}
	public void setClassattendance(String classattendance) {
		this.classattendance = classattendance;
	}
	public String getLabattendance() {
		return labattendance;
	}
	public void setLabattendance(String labattendance) {
		this.labattendance = labattendance;
	}
	public String getInternalviva() {
		return internalviva;
	}
	public void setInternalviva(String internalviva) {
		this.internalviva = internalviva;
	}
	public String getLabperformance() {
		return labperformance;
	}
	public void setLabperformance(String labperformance) {
		this.labperformance = labperformance;
	}
	public String getTotal() {
		return total;
	}
	
}
