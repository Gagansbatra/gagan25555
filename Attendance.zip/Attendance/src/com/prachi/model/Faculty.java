package com.prachi.model;

public class Faculty {
	private  String FacultyID;
	private String FacultyName;
	private  String FacultyBirthDate;
	private String FacultyGender;
	private String FacultyAddress;
	private String country;
	private String state;
	private String city;
	
	private  String FacultyCNO;
	public String getFacultyAddress() {
		return FacultyAddress;
	}
	public void setFacultyAddress(String facultyAddress) {
		FacultyAddress = facultyAddress;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getFacultyID() {
		return FacultyID;
	}
	public void setFacultyID(String facultyID) {
		FacultyID = facultyID;
	}
	public String getFacultyName() {
		return FacultyName;
	}
	public void setFacultyName(String facultyName) {
		FacultyName = facultyName;
	}
	public String getFacultyBirthDate() {
		return FacultyBirthDate;
	}
	public void setFacultyBirthDate(String facultyBirthDate) {
		FacultyBirthDate = facultyBirthDate;
	}
	public String getFacultyGender() {
		return FacultyGender;
	}
	public void setFacultyGender(String facultyGender) {
		FacultyGender = facultyGender;
	}
	public String getFacultyCNO() {
		return FacultyCNO;
	}
	public void setFacultyCNO(String facultyCNO) {
		FacultyCNO = facultyCNO;
	}
	public String getFacultyEmailID() {
		return FacultyEmailID;
	}
	public void setFacultyEmailID(String facultyEmailID) {
		FacultyEmailID = facultyEmailID;
	}
	public String getFacultyBranch() {
		return FacultyBranch;
	}
	public void setFacultyBranch(String facultyBranch) {
		FacultyBranch = facultyBranch;
	}
	public String getFacultyDesignation() {
		return FacultyDesignation;
	}
	public void setFacultyDesignation(String facultyDesignation) {
		FacultyDesignation = facultyDesignation;
	}
	public String getFacultyPhotograph() {
		return FacultyPhotograph;
	}
	public void setFacultyPhotograph(String facultyPhotograph) {
		FacultyPhotograph = facultyPhotograph;
	}
	public String getFacultyPassword() {
		return FacultyPassword;
	}
	public void setFacultyPassword(String facultyPassword) {
		FacultyPassword = facultyPassword;
	}
	private String FacultyEmailID;
	private  String FacultyBranch;
	private String FacultyDesignation;
	private  String FacultyPhotograph;
	private String FacultyPassword;
	
	

}
