package com.prachi.model;

public class Student {
private  String enrollmentno;
private String name;
private  String fathername;
private  String gender;
private String birthdate;
private  String address;
private String country ;
private  String state;
private String city;
private  String contactno;
private String mobileno;
private  String stdemailid;
private String fatheremailid;
private  String branch;
private String sem;
private  String year;
private String photograph;
private  String password;
public String getEnrollmentno() {
	return enrollmentno;
}
public void setEnrollmentno(String enrollmentno) {
	this.enrollmentno = enrollmentno;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getFathername() {
	return fathername;
}
public void setFathername(String fathername) {
	this.fathername = fathername;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public String getBirthdate() {
	return birthdate;
}
public void setBirthdate(String birthdate) {
	this.birthdate = birthdate;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getCountry() {
	return country;
}
public void setCountry(String country) {
	this.country = country;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getContactno() {
	return contactno;
}
public void setContactno(String contactno) {
	this.contactno = contactno;
}
public String getMobileno() {
	return mobileno;
}
public void setMobileno(String mobileno) {
	this.mobileno = mobileno;
}
public String getStdemailid() {
	return stdemailid;
}
public void setStdemailid(String stdemailid) {
	this.stdemailid = stdemailid;
}
public String getFatheremailid() {
	return fatheremailid;
}
public void setFatheremailid(String fatheremailid) {
	this.fatheremailid = fatheremailid;
}
public String getBranch() {
	return branch;
}
public void setBranch(String branch) {
	this.branch = branch;
}
public String getSem() {
	return sem;
}
public void setSem(String sem) {
	this.sem = sem;
}
public String getYear() {
	return year;
}
public void setYear(String year) {
	this.year = year;
}
public String getPhotograph() {
	return photograph;
}
public void setPhotograph(String photograph) {
	this.photograph = photograph;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}


}
