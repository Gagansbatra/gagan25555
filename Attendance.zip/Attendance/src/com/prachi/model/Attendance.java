package com.prachi.model;

public class Attendance {
	private String transtrationid;
	 private String facultyid;
	 private String enrollmentno;
	 private String branchid;
	 
	 public String getFacultyid() {
		return facultyid;
	}
	public void setFacultyid(String facultyid) {
		this.facultyid = facultyid;
	}
	private String semester;
	 private String subject;
	 private String currentdate;
	 private String status;
	public String getTranstrationid() {
		return transtrationid;
	}
	public void setTranstrationid(String transtrationid) {
		this.transtrationid = transtrationid;
	}
	public String getEnrollmentno() {
		return enrollmentno;
	}
	public void setEnrollmentno(String enrollmentno) {
		this.enrollmentno = enrollmentno;
	}
	public String getBranchid() {
		return branchid;
	}
	public void setBranchid(String branchid) {
		this.branchid = branchid;
	}
	public String getSemester() {
		return semester;
	}
	public void setSemester(String semester) {
		this.semester = semester;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getCurrentdate() {
		return currentdate;
	}
	public void setCurrentdate(String currentdate) {
		this.currentdate = currentdate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
 {
		// TODO Auto-generated method stub
		
	}

	// TODO Auto-generated method stub
	
	 
}
